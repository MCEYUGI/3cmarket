<?php
// 資料庫連線設定
include 'connect.php';

// 接收與處理表單資料
function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$customer_name  = sanitize($_POST['customer_name']);
$gender         = sanitize($_POST['gender']);
$age            = intval($_POST['age']);
$phone          = sanitize($_POST['phone']);
$address        = sanitize($_POST['address']);
$email          = sanitize($_POST['email']);

// 驗證欄位
if (empty($customer_name) || empty($phone)) {
    echo "<script>alert('請填寫必填欄位（姓名與電話）！'); history.back();</script>";
    exit();
}

// 寫入資料
$sql = "INSERT INTO customers (customer_name, gender, age, phone, address, email)
        VALUES (:customer_name, :gender, :age, :phone, :address, :email)";

$stmt = $conn->prepare($sql);
$stmt->execute([
    ':customer_name' => $customer_name,
    ':gender' => $gender,
    ':age' => $age,
    ':phone' => $phone,
    ':address' => $address,
    ':email' => $email
]);

echo "<script>alert('客戶新增成功！'); window.location.href='insert2.html';</script>";
?>

<?php
header('Content-Type: application/json; charset=utf-8');
include 'connect.php';

if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];
    
    try {
        $stmt = $conn->prepare("SELECT name, price FROM products WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($product) {
            echo json_encode([
                'success' => true,
                'name' => $product['name'],
                'price' => $product['price']
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => '產品不存在'
            ]);
        }
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => '資料庫錯誤：' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => '缺少產品ID參數'
    ]);
}
?> 
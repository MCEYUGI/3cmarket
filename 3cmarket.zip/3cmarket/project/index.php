<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <title>創客3C市集平台</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="header">
        <h1><a href="index.php" style="color: white; text-decoration: none;">創客3C市集平台</a></h1>
        <span class="brand">MakerZone</span>
    </div>

    <nav>
        <ul class="menu">
            <li class="dropdown">
                <a href="#">訂單管理</a>
                <ul class="submenu">
                    <li><a href="insert1.html">訂單新增</a></li>
                    <li><a href="search1.html">訂單查詢</a></li>
                    <li><a href="update1.html">訂單維護</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">客戶管理</a>
                <ul class="submenu">
                    <li><a href="insert2.html">客戶新增</a></li>
                    <li><a href="search2.html">客戶查詢</a></li>
                    <li><a href="update2.html">客戶維護</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">產品管理</a>
                <ul class="submenu">
                    <li><a href="insert3.html">產品新增</a></li>
                    <li><a href="search3.html">產品查詢</a></li>
                    <li><a href="update3.html">產品維護</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">供應商管理</a>
                <ul class="submenu">
                    <li><a href="insert4.html">供應商新增</a></li>
                    <li><a href="search4.html">供應商查詢</a></li>
                    <li><a href="update4.html">供應商維護</a></li>
                </ul>
            </li>
            <li><a href="analysis.php">數據分析</a></li>
        </ul>
    </nav>

    <div class="product-list">
        <div class="full-width-title">
            <h2>最新產品清單</h2>
        </div>
        <?php
        include 'connect.php';
        $products = $conn->query("SELECT * FROM products ORDER BY created_at DESC")->fetchAll();
        ?>
        <?php foreach ($products as $p): ?>
            <div class="product-card">
                <h3><?= htmlspecialchars($p['name']) ?></h3>
                <p>產品編號：<?= htmlspecialchars($p['product_id']) ?></p>
                <p>價格：$<?= $p['price'] ?></p>
                <p>庫存：<?= $p['stock'] ?></p>
                <p>狀態：<span class="<?= ($p['status'] === 'Active' && $p['stock'] > 0) ? 'status-active' : 'status-inactive' ?>">
                    <?= ($p['status'] === 'Active' && $p['stock'] > 0) ? '上架' : '下架' ?>
                </span></p>
                <p><?= nl2br(htmlspecialchars($p['description'])) ?></p>
                <p class="timestamp">建立時間：<?= $p['created_at'] ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>

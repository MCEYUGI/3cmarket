<?php
header("Content-Type:text/html; charset=utf-8");
?>

<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>產品修改結果</title>
  <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
<div id="header">
  <h1>產品修改結果</h1>
</div>

<div id="contents">
  <h2 style="text-align:center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>

<?php
  include "connect.php";

  $product_id = $_POST['product_id'];
  $name = $_POST['name'];
  $price = $_POST['price'];
  $description = $_POST['description'];
  $stock = $_POST['stock'];
  $status = $_POST['status'];

  // 1. 開始交易
  //sqlsrv_begin_transaction($conn);

  try {
    $conn->beginTransaction();

    $sql = "UPDATE dbo.products SET 
                name = :name,
                price = :price,
                description = :description,
                stock = :stock,
                status = :status
            WHERE product_id = :product_id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':stock', $stock);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':product_id', $product_id);

    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $conn->commit();
        echo "<div class='center-black'><p>產品編號: ".$product_id." 資料已修改完成。</p><p>請點首頁回到系統管理畫面!</p></div>";
    } else {
        $conn->rollBack();
        echo "<div class='center-black'>資料未更新（可能資料相同），交易已回滾。</div>";
    }
} catch (PDOException $e) {
    $conn->rollBack();
    echo "<div class='center-black'><p>修改失敗：交易已回滾</p><pre>".$e->getMessage()."</pre></div>";
}

  // 4. 結束連線（可選）
  $conn = null;
?>
</div>
</body>
</html>
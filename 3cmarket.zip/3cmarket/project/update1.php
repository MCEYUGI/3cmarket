<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>訂單資料維護</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
  <div id="header">
    <h1>訂單資料維護</h1>
  </div>
    
<div id="contents">
<h2 style="text-align: center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>
<?php
        // For macOS: Connect to SQL Server via ODBC Driver 17 and trust server certificate
        include 'connect.php';
		if(empty($_POST['order_id']))	
		{
			echo "<div class='center-black'>!!!! 請輸入訂單代號 !!!</div>";
		}
		else
		{        
	    $orderid=$_POST['order_id'];
		$sql = "SELECT * FROM dbo.orders WHERE order_id = :orderid";
		$stmt = $conn->prepare($sql);
		$stmt->execute([':orderid' => $orderid]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // 查詢所有訂單細項（order_details）
        $sql_detail = "SELECT od.*, p.name FROM dbo.order_details od 
                       JOIN dbo.products p ON od.product_id = p.product_id 
                       WHERE od.order_id = :orderid";
        $stmt_detail = $conn->prepare($sql_detail);
        $stmt_detail->execute([':orderid' => $orderid]);
        $details = $stmt_detail->fetchAll(PDO::FETCH_ASSOC);
		if(empty($row['order_id']))	
		{
			echo "<div class='center-black'>!!! 無此訂單代號 !!!</div>";
		}
		else
		{	
?>
        <form name="form" action="http://localhost:8080/project/update_data_1.php" method="post" accept-charset="UTF-8">
		<div class="detail_box clearfix">
        <div class="form-card">
        <h3 style="text-align: center; color: black;">修改訂單資料</h3>
            <label for="customerid">Order ID:</label>
            <input type="text" id="order_id" name="order_id" value="<?php echo $orderid;?>" readonly style="font-size: 14px;" />
            <label for="order_date">Order Date:</label>
            <input type="date" id="order_date" name="order_date" value="<?php echo $row['order_date']; ?>" style="font-size: 14px;" />
        
            <label for="customer_id">Customer ID:</label>
            <input type="text" id="customer_id" name="customer_id" value="<?php echo $row['customer_id']; ?>" style="font-size: 14px;" />
            
            <?php foreach ($details as $index => $detail): ?>
            <div style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px;">
                <label>Product ID:</label>
                <input type="text" name="product_id[]" value="<?php echo $detail['product_id']; ?>" 
                       style="font-size: 14px;" onchange="updateProductName(this, <?php echo $index; ?>)" />

                <label>Product Name:</label>
                <input type="text" id="product_name_<?php echo $index; ?>" value="<?php echo $detail['name']; ?>" 
                       style="font-size: 14px;" readonly />

                <label>Quantity:</label>
                <input type="number" name="quantity[]" value="<?php echo $detail['quantity']; ?>" style="font-size: 14px;" />

                <label>Price:</label>
                <input type="text" name="price[]" value="<?php echo $detail['price']; ?>" style="font-size: 14px;" readonly />
            </div>
            <?php endforeach; ?>
            
            <label for="payment">Payment:</label>
            <div class="mydict">
                <div>
                    <label>
                        <input type="radio" id="payment" name="payment" value="信用卡" <?php if($row['payment'] == '信用卡') echo 'checked'; ?>>
                        <span>信用卡</span>
                    </label>
                    <label>
                        <input type="radio" id="payment" name="payment" value="貨到付款" <?php if($row['payment'] == '貨到付款') echo 'checked'; ?>>
                        <span>貨到付款</span>
                    </label>
                    <label>
                        <input type="radio" id="payment" name="payment" value="LINE Pay" <?php if($row['payment'] == 'LINE Pay') echo 'checked'; ?>>
                        <span>LINE Pay</span>
                    </label>
                    <label>
                        <input type="radio" id="payment" name="payment" value="銀行轉帳" <?php if($row['payment'] == '銀行轉帳') echo 'checked'; ?>>
                        <span>銀行轉帳</span>
                    </label>
                </div>
            </div>
            
            <label for="note">Note:</label>
            <textarea id="note" name="note" class="styled-note"><?php echo $row['note']; ?></textarea>
            
            <input type="reset" value="清除表單" style="font-size: 14px;"/>
            <input id="submit" name="submit" type="submit" value="送出" style="font-size: 14px;" />
        </div>
        </div>
    </form>	
	<?php	} }?>
</div>

<script>
function updateProductName(input, index) {
    const productId = input.value;
    const nameInput = document.getElementById('product_name_' + index);
    const priceInput = input.parentNode.querySelector('input[name="price[]"]');
    
    if (productId) {
        // 發送AJAX請求獲取產品資訊
        fetch('get_product_info.php?product_id=' + productId)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    nameInput.value = data.name;
                    priceInput.value = data.price;
                } else {
                    nameInput.value = '產品不存在';
                    priceInput.value = '';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                nameInput.value = '獲取失敗';
                priceInput.value = '';
            });
    } else {
        nameInput.value = '';
        priceInput.value = '';
    }
}
</script>

</body>
</html>
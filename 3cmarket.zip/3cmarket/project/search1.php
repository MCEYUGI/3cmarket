<?php
include 'connect.php';

function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$customer_id = sanitize($_POST['customer_id']);
$order_date    = sanitize($_POST['order_date']);

if (empty($customer_id) || empty($order_date)) {
    echo "<script>alert('請填寫必填欄位（客戶編號與訂單日期）！'); history.back();</script>";
    exit();
}

$sql = "
SELECT 
    o.order_id,
    o.order_date,
    o.customer_id,
    p.name AS product_name,
    od.quantity,
    od.price,
    od.quantity * od.price AS subtotal
FROM orders o
JOIN order_details od ON o.order_id = od.order_id
JOIN products p ON od.product_id = p.product_id
WHERE o.customer_id = :customer_id AND o.order_date = :order_date
";

$stmt = $conn->prepare($sql);
$stmt->execute([
    ':customer_id' => $customer_id,
    ':order_date' => $order_date
]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($orders) > 0) {
    echo "<h2>訂單查詢結果</h2><table border='1' cellpadding='8'><tr>
            <th>訂單編號</th>
            <th>訂單日期</th>
            <th>客戶編號</th>
            <th>產品名稱</th>
            <th>數量</th>
            <th>單價</th>
            <th>小計</th>
          </tr>";
    foreach ($orders as $order) {
        echo "<tr>
                <td>{$order['order_id']}</td>
                <td>{$order['order_date']}</td>
                <td>{$order['customer_id']}</td>
                <td>{$order['product_name']}</td>
                <td>{$order['quantity']}</td>
                <td>{$order['price']}</td>
                <td>{$order['subtotal']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<script>alert('查無訂單紀錄'); history.back();</script>";
}
?>
<?php
include 'connect.php';
$stmt = $conn->prepare("SELECT * FROM products WHERE status = 'Active' AND stock > 0 ORDER BY created_at DESC");
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
header('Content-Type: application/json');
echo json_encode($products);
?>
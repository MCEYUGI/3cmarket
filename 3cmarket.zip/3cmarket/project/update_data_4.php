<?php
header("Content-Type:text/html; charset=utf-8");
?>

<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>供應商修改結果</title>
  <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
<div id="header">
  <h1>供應商修改結果</h1>
</div>

<div id="contents">
  <h2 style="text-align:center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>
<?php
  include "connect.php";

  $supplier_id   = $_POST['supplier_id'];
  $supplier_name = $_POST['supplier_name'];
  $contact_name  = $_POST['contact_name'];
  $phone         = $_POST['phone'];
  $email         = $_POST['email'];
  $address       = $_POST['address'];
  $start_date    = $_POST['start_date'];
  $notes         = $_POST['notes'];

  try {
    $conn->beginTransaction();

    // 更新供應商資料
    $sql = "UPDATE dbo.suppliers SET 
                supplier_name = :supplier_name,
                contact_name = :contact_name,
                phone = :phone,
                email = :email,
                address = :address,
                start_date = :start_date,
                notes = :notes
            WHERE supplier_id = :supplier_id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':supplier_name', $supplier_name);
    $stmt->bindParam(':contact_name', $contact_name);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':notes', $notes);
    $stmt->bindParam(':supplier_id', $supplier_id);

    $stmt->execute();

    if ($stmt->rowCount() > 0) {
      $conn->commit();
      echo "<div class='center-black'><p>供應商編號: ".$supplier_id." 資料已修改完成。</p><p>請點首頁回到系統管理畫面!</p></div>";
    } else {
        $conn->rollBack();
        echo "<div class='center-black'>資料未更新（可能資料相同），交易已回滾。</div>";
    }
  } catch (PDOException $e) {
    $conn->rollBack();
    echo "<div class='center-black'><p>修改失敗：交易已回滾</p><pre>".$e->getMessage()."</pre></div>";
  }

  $conn = null;
?>
</div>
</body>
</html>
<?php
header("Content-Type:text/html; charset=utf-8");
?>

<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>訂單修改結果</title>
  <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
<div id="header">
  <h1>訂單修改結果</h1>
</div>

<div id="contents">
  <h2 style="text-align:center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>

<?php
  include "connect.php";

  $order_id = $_POST['order_id'];
  $order_date = $_POST['order_date'];
  $customer_id = $_POST['customer_id'];
  $payment = $_POST['payment'];
  $note = $_POST['note'];
  // 支援多商品
  $product_ids = $_POST['product_id'];
  $quantities = $_POST['quantity'];
  $prices = $_POST['price'];
  // 1. 開始交易
  //sqlsrv_begin_transaction($conn);

  try {
    $conn->beginTransaction();

    // 只更新 orders 表中的一般資料
    $sql = "UPDATE dbo.orders SET 
                order_date = :order_date,
                customer_id = :customer_id,
                payment = :payment,
                note = :note
            WHERE order_id = :order_id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':order_date', $order_date);
    $stmt->bindParam(':customer_id', $customer_id);
    $stmt->bindParam(':payment', $payment);
    $stmt->bindParam(':note', $note);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();

    // 刪除舊的訂單細項
    $deleteDetailsSQL = "DELETE FROM order_details WHERE order_id = :order_id";
    $deleteStmt = $conn->prepare($deleteDetailsSQL);
    $deleteStmt->execute([':order_id' => $order_id]);

    // 根據每筆產品重新新增細項並更新庫存
    for ($i = 0; $i < count($product_ids); $i++) {
        $pid = (int)$product_ids[$i];
        $qty = (int)$quantities[$i];
        $prc = (float)$prices[$i];

        // 檢查庫存並獲取產品名稱
        $checkStockSQL = "SELECT stock, name FROM products WHERE product_id = :pid";
        $checkStockStmt = $conn->prepare($checkStockSQL);
        $checkStockStmt->execute([':pid' => $pid]);
        $stockRow = $checkStockStmt->fetch(PDO::FETCH_ASSOC);

        if (!$stockRow || $stockRow['stock'] < $qty) {
            $productName = $stockRow ? $stockRow['name'] : "未知產品";
            throw new Exception("產品「{$productName}」(ID: $pid) 庫存不足。");
        }

        // 插入 order_details
        $insertDetailSQL = "INSERT INTO order_details (order_id, product_id, quantity, price) 
                            VALUES (:order_id, :pid, :qty, :prc)";
        $insertStmt = $conn->prepare($insertDetailSQL);
        $insertStmt->execute([
            ':order_id' => $order_id,
            ':pid' => $pid,
            ':qty' => $qty,
            ':prc' => $prc
        ]);

        // 更新庫存
        $updateStockSQL = "UPDATE products SET stock = stock - :qty WHERE product_id = :pid";
        $updateStmt = $conn->prepare($updateStockSQL);
        $updateStmt->execute([':qty' => $qty, ':pid' => $pid]);
    }

    $conn->commit();
    echo "<div class='center-black'><p>訂單編號: ".$order_id." 資料已修改完成。</p><p>請點首頁回到系統管理畫面!</p></div>";
} catch (PDOException $e) {
    $conn->rollBack();
    echo "<div class='center-black'><p>修改失敗：交易已回滾</p><pre>".$e->getMessage()."</pre></div>";
} catch (Exception $e) {
    $conn->rollBack();
    echo "<div class='center-black'><p>修改失敗：交易已回滾</p><pre>".$e->getMessage()."</pre></div>";
}

  // 4. 結束連線（可選）
  $conn = null;
?>
</div>
</body>
</html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>客戶資料維護</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
  <div id="header">
    <h1>客戶資料維護</h1>
  </div>
    
<div id="contents">
<h2 style="text-align: center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>
<?php
        // For macOS: Connect to SQL Server via ODBC Driver 17 and trust server certificate
        include 'connect.php';
		if(empty($_POST['product_id']))	
		{
			echo "<div class='center-black'>!!!! 請輸入客戶代號 !!!</div>";
		}
		else
		{        
	    $productid=$_POST['product_id'];
		$sql = "SELECT * FROM dbo.products WHERE product_id = :productid";
		$stmt = $conn->prepare($sql);
		$stmt->execute([$productid]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
		if(empty($row['product_id']))	
		{
			echo"<div class='center-black'>!!! 無此客戶代號 !!!</div>";
		}
		else
		{	
?>
        <form name="form" action="http://localhost:8080/project/update_data_3.php" method="post" accept-charset="UTF-8">
		<div class="detail_box clearfix">
        <div class="form-card">
            <h3 style="text-align: center; color: black;">修改產品資料</h3>
            <label for="productid">Product ID:</label>
            <input type="text" id="productid" name="product_id" value="<?php echo $row['product_id']; ?>" readonly style="font-size: 14px;" />

            <label for="name">Product Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>" style="font-size: 14px;" />

            <label for="price">Price:</label>
            <input type="text" id="price" name="price" value="<?php echo $row['price']; ?>" style="font-size: 14px;" />

            <label for="description">Description:</label>
            <input type="text" id="description" name="description" value="<?php echo $row['description']; ?>" style="font-size: 14px;" />

            <label for="stock">Stock:</label>
            <input type="text" id="stock" name="stock" value="<?php echo $row['stock']; ?>" style="font-size: 14px;" />

            <label for="status">Status:</label>
            <input type="text" id="status" name="status" value="<?php echo $row['status']; ?>" style="font-size: 14px;" />

            <input type="reset" value="清除表單" style="font-size: 14px;" />
            <input id="submit" name="submit" type="submit" value="送出" style="font-size: 14px;" />
        </div>
        </div>
        </form>	
		<?php	} }?>
</div>

</body>
</html>
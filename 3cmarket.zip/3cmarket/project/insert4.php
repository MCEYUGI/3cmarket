<?php
// 資料庫連線設定
include 'connect.php';

// 接收與處理表單資料
function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$supplier_name = sanitize($_POST['supplier_name']);
$contact_name  = sanitize($_POST['contact_name']);
$phone         = sanitize($_POST['phone']);
$email         = sanitize($_POST['email']);
$address       = sanitize($_POST['address']);
$start_date    = sanitize($_POST['start_date']);
$notes         = sanitize($_POST['notes']);

// 驗證欄位
if (empty($supplier_name) || empty($phone)) {
    echo "<script>alert('請填寫必填欄位（供應商名稱與聯絡電話）！'); history.back();</script>";
    exit();
}

// 寫入資料
$sql = "INSERT INTO suppliers (supplier_name, contact_name, phone, email, address, start_date, notes)
        VALUES (:supplier_name, :contact_name, :phone, :email, :address, :start_date, :notes)";

$stmt = $conn->prepare($sql);
$stmt->execute([
    ':supplier_name' => $supplier_name,
    ':contact_name'  => $contact_name,
    ':phone'         => $phone,
    ':email'         => $email,
    ':address'       => $address,
    ':start_date'    => $start_date,
    ':notes'         => $notes
]);

echo "<script>alert('供應商新增成功！'); window.location.href='insert4.html';</script>";
?>

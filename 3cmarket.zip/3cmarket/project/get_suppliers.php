<?php
header('Content-Type: application/json; charset=utf-8');
include 'connect.php';

try {
    $stmt = $conn->query("SELECT supplier_id, supplier_name, contact_name, phone FROM suppliers ORDER BY supplier_name");
    $suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($suppliers, JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    echo json_encode([
        'error' => true,
        'message' => '資料庫錯誤：' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?> 
<?php
include 'connect.php';

$product_id = $_POST['product_id'] ?? '';

$sql = "SELECT * FROM products WHERE 1=1";
$params = [];

if (!empty($product_id)) {
    $sql .= " AND product_id = :product_id";
    $params[':product_id'] = $product_id;
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>客戶查詢結果</title>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>產品查詢結果</h2>
    <?php if (count($results) > 0): ?>
        <table border="1">
            <tr>
                <th>產品編號</th>
                <th>名稱</th>
                <th>價格</th>
                <th>描述</th>
                <th>庫存</th>
                <th>狀態</th>
                <th>建立時間</th>
                <th>更新時間</th>
            </tr>
            <?php foreach ($results as $row): ?>
                <tr>
                    <td><?php echo $row['product_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                    <td><?php echo $row['stock']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td><?php echo $row['updated_at']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>查無產品資料。</p>
    <?php endif; ?>
</body>
</html>
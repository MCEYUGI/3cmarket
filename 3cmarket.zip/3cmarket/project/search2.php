<?php
include 'connect.php';

$customer_name = $_POST['customer_name'] ?? '';
$age = $_POST['age'] ?? '';
$order_date = $_POST['order_date'] ?? '';
$product_name = $_POST['product_name'] ?? '';

$sql = "SELECT * FROM customers WHERE 1=1";
$params = [];

if (!empty($customer_name)) {
    $sql .= " AND customer_name LIKE :customer_name";
    $params[':customer_name'] = "%$customer_name%";
}
if (!empty($age)) {
    $sql .= " AND age = :age";
    $params[':age'] = $age;
}
if (!empty($order_date)) {
    $sql .= " AND order_date = :order_date";
    $params[':order_date'] = $order_date;
}
if (!empty($product_name)) {
    $sql .= " AND product_name LIKE :product_name";
    $params[':product_name'] = "%$product_name%";
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>客戶查詢結果</title>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>查詢結果</h2>
    <?php if (count($results) > 0): ?>
        <table border="1">
            <tr>
                <th>客戶ID</th>
                <th>姓名</th>
                <th>性別</th>
                <th>年齡</th>
                <th>電話</th>
                <th>地址</th>
                <th>Email</th>
            </tr>
            <?php foreach ($results as $row): ?>
                <tr>
                    <td><?php echo $row['customer_id']; ?></td>
                    <td><?php echo $row['customer_name']; ?></td>
                    <td><?php echo $row['gender']; ?></td>
                    <td><?php echo $row['age']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['address']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>查無資料。</p>
    <?php endif; ?>
</body>
</html>

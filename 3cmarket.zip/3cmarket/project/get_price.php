<?php
// get_price.php
include 'connect.php';

if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];
    $stmt = $conn->prepare("SELECT price FROM products WHERE product_id = ?");
    $stmt->execute([$product_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo $row ? $row['price'] : '';
}
?>
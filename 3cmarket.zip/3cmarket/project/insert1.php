<?php
// 資料庫連線設定
include 'connect.php';

$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 自動產生訂單編號
$order_id = 'ORD' . date('YmdHis');

// 接收與處理表單資料
function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$order_date     = sanitize($_POST['order_date']);
$customer_id    = sanitize($_POST['customer_id']);
$payment        = sanitize($_POST['payment']);
$note           = sanitize($_POST['note']);
$cart           = json_decode($_POST['cart'], true);

$missing = [];
if (empty($order_date)) $missing[] = '訂單日期';
if (empty($customer_id)) $missing[] = '客戶編號';
if (empty($payment)) $missing[] = '付款方式';
if (empty($cart)) $missing[] = '購物車內容';

if (!empty($missing)) {
    $msg = implode('、', $missing) . ' 為必填欄位！';
    echo "<script>alert('$msg'); history.back();</script>";
    exit();
}

// 檢查客戶編號是否存在
$checkCustomer = $conn->prepare("SELECT COUNT(*) FROM customers WHERE customer_id = :customer_id");
$checkCustomer->execute([':customer_id' => $customer_id]);
if ($checkCustomer->fetchColumn() == 0) {
    echo "<script>alert('客戶編號不存在，請先新增客戶資料！'); history.back();</script>";
    exit();
}

// 寫入資料
$totalPrice = 0;
try {
    $conn->beginTransaction();

    $sqlOrder = "INSERT INTO orders (order_id, order_date, customer_id, payment, note)
                 VALUES (:order_id, :order_date, :customer_id, :payment, :note)";
    $stmtOrder = $conn->prepare($sqlOrder);
    $stmtOrder->execute([
        ':order_id' => $order_id,
        ':order_date' => $order_date,
        ':customer_id' => $customer_id,
        ':payment' => $payment,
        ':note' => $note
    ]);

    $sqlDetail = "INSERT INTO order_details (order_id, product_id, quantity, price)
                  VALUES (:order_id, :product_id, :quantity, :price)";
    $stmtDetail = $conn->prepare($sqlDetail);

    foreach ($cart as $item) {
        $product_id = sanitize($item['product_id']);
        $quantity = intval($item['quantity']);
        $price = floatval($item['price']);

        if (empty($product_id) || $quantity <= 0 || $price <= 0) {
            echo "<script>alert('購物車資料無效！'); history.back();</script>";
            exit();
        }

        $stmtDetail->execute([
            ':order_id' => $order_id,
            ':product_id' => $product_id,
            ':quantity' => $quantity,
            ':price' => $price
        ]);

        // 更新產品庫存
        $updateStockSQL = "UPDATE products SET stock = stock - :quantity WHERE product_id = :product_id";
        $updateStmt = $conn->prepare($updateStockSQL);
        $updateStmt->execute([
            ':quantity' => $quantity,
            ':product_id' => $product_id
        ]);

        $totalPrice += $price * $quantity;
    }

    $conn->commit();
    echo "<script>alert('訂單新增成功！總金額：$totalPrice'); window.location.href='insert1.html';</script>";

} catch (Exception $e) {
    if ($conn->inTransaction()) {
        $conn->rollback();
    }
    echo "<script>alert('訂單新增失敗: " . $e->getMessage() . "'); history.back();</script>";
    exit();
}

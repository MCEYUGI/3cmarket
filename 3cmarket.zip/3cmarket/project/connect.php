<?php
$dsn = "sqlsrv:server=localhost;Database=makerzone";
$user = "SA";
$password = "MyStrongPass123";

try {
    $conn = new PDO($dsn, $user, $password, [
        PDO::SQLSRV_ATTR_ENCODING => PDO::SQLSRV_ENCODING_UTF8
    ]);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // 開發階段偵錯用
} catch (PDOException $e) {
    die("<div class='center-black'>連線失敗：" . $e->getMessage() . "</div>");
}
?>
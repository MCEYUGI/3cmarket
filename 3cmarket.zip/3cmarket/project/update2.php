<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>客戶資料維護</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
  <div id="header">
    <h1>客戶資料維護</h1>
  </div>
    
<div id="contents">
<h2 style="text-align: center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>
<?php
        // For macOS: Connect to SQL Server via ODBC Driver 17 and trust server certificate
        include 'connect.php';
		if(empty($_POST['customer_id']))	
		{
			echo "<div class='center-black'>!!!! 請輸入客戶代號 !!!</div>";
		}
		else
		{        
	    $customerid=$_POST['customer_id'];
		$sql = "SELECT * FROM dbo.customers WHERE customer_id = :customerid";
		$stmt = $conn->prepare($sql);
		$stmt->execute([$customerid]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
		if(empty($row['customer_id']))	
		{
			echo"<div class='center-black'>!!! 無此客戶代號 !!!</div>";
		}
		else
		{	
?>
        <form name="form" action="http://localhost:8080/project/update_data_2.php" method="post" accept-charset="UTF-8">
		<div class="detail_box clearfix">
        <div class="form-card">
        <h3 style="text-align: center; color: black;">修改客戶資料</h3>
            <label for="customerid">Customer ID:</label>
            <input type="text" id="customerid" name="customer_id" value="<?php echo $customerid;?>" readonly style="font-size: 14px;" />
            
            <label for="customername">Customer Name:</label>
            <input type="text" id="customername" name="customername" value="<?php echo $row['customer_name']; ?>" style="font-size: 14px;" />
            
            <label for="gender">Gender:</label>
            <select id="gender" name="gender" size="1" style="font-size: 14px;">
                <option value="Male" <?php if($row['gender'] == 'Male') echo 'selected'; ?>>Male</option>
                <option value="Female" <?php if($row['gender'] == 'Female') echo 'selected'; ?>>Female</option>
                <option value="Other" <?php if($row['gender'] == 'Other') echo 'selected'; ?>>Other</option>
            </select>
            
            <label for="age">Age:</label>
            <input type="text" id="age" name="age" value="<?php echo $row['age']; ?>" style="font-size: 14px;"/>
            
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo $row['phone']; ?>" style="font-size: 14px;"/>
            
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="<?php echo $row['address']; ?>" style="font-size: 14px;"/>
            
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" value="<?php echo $row['email']; ?>" style="font-size: 14px;"/>
            
            <input type="reset" value="清除表單" style="font-size: 14px;"/>
            <input id="submit" name="submit" type="submit" value="送出" style="font-size: 14px;" />
        </div>
        </div>
        </form>	
		<?php	} }?>
</div>

</body>
</html>
<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <title>創客3C市集平台</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .chart-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 30px;
            transition: transform 0.2s;
            min-width: 320px;
            height: 420px;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }
        .chart-container:hover {
            transform: translateY(-5px);
        }
        .chart-container h2 {
            margin-bottom: 18px !important;
        }
        .btn-primary {
            background-color: #0d6efd;
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        h2 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 25px !important;
            position: relative;
            padding-bottom: 10px;
        }
        h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 3px;
            background-color: #0d6efd;
            border-radius: 2px;
        }
        .table {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .table thead th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }
    
        .button-bar {
            width: 100%;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 18px;
            margin: 32px 0 40px 0;
        }

        canvas {
            width: 100% !important;
            height: 100% !important;
            max-height: unset;
            display: block;
        }
    </style>
</head>
<body>
    <div id="header">
        <h1><a href="index.php" style="color: white; text-decoration: none;">創客3C市集平台</a></h1>
        <span class="brand">MakerZone</span>
    </div>
    <?php
    // 請將本檔案從 index.html 重新命名為 index.php 以啟用以下 PHP 程式碼
    include 'connect.php';
    // 計算圖表數量（不含庫存不足表格）
    $chart_count = 7; // 7 個 canvas 圖表
    ?>

    <div class="container mt-4">
        <?php if ($chart_count >= 3): ?>
        <div class="w-100 button-bar">
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('topProductsChart')">熱門產品排行</button>
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('topCustomersChart')">客戶訂單排行</button>
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('dailySalesChart')">每日銷售</button>
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('supplierStatsChart')">供應商統計</button>
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('lowStockTable')">庫存不足</button>
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('salesAmountChart')">產品銷售金額</button>
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('cityOrderChart')">各城市訂單</button>
            <button class="btn btn-primary px-4 py-2" onclick="scrollToChart('weekdaySalesChart')">一週銷售變化</button>
        </div>
        <?php endif; ?>
        <div class="row g-4">
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">熱門產品銷售排行</h2>
                    <canvas id="topProductsChart"></canvas>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">客戶訂購次數排行</h2>
                    <canvas id="topCustomersChart"></canvas>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">每日銷售統計</h2>
                    <canvas id="dailySalesChart"></canvas>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">供應商提供商品數量統計</h2>
                    <canvas id="supplierStatsChart"></canvas>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">庫存不足商品</h2>
                    <div id="lowStockTable" class="table-responsive"></div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">各產品銷售金額總計</h2>
                    <canvas id="salesAmountChart"></canvas>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">各城市訂單數量</h2>
                    <canvas id="cityOrderChart"></canvas>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="chart-container" style="min-width:320px;">
                    <h2 class="text-center">每週銷售變化趨勢</h2>
                    <canvas id="weekdaySalesChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <?php
    // 熱門產品
    $stmt1 = $conn->query("
        SELECT TOP 10 p.name AS product_name, SUM(od.quantity) AS total_quantity
        FROM order_details od
        JOIN products p ON od.product_id = p.product_id
        GROUP BY p.name
        ORDER BY total_quantity DESC
    ");
    $products = $stmt1->fetchAll(PDO::FETCH_ASSOC);
    $productNames = json_encode(array_column($products, 'product_name'), JSON_UNESCAPED_UNICODE);
    $productQuantities = json_encode(array_column($products, 'total_quantity'));

    // 客戶訂購排行
    $stmt2 = $conn->query("
        SELECT TOP 10 o.customer_id, COUNT(DISTINCT o.order_id) AS order_count, SUM(od.quantity * od.price) AS total_spent, AVG(od.quantity * od.price) AS avg_order_value
        FROM orders o
        JOIN order_details od ON o.order_id = od.order_id
        GROUP BY o.customer_id
        ORDER BY order_count DESC
    ");
    $customers = $stmt2->fetchAll(PDO::FETCH_ASSOC);
    $customerIds = json_encode(array_map(function($item) {
        return $item['customer_id'] . ' (總消費：' . $item['total_spent'] . ', 平均訂單：' . $item['avg_order_value'] . ')';
    }, $customers), JSON_UNESCAPED_UNICODE);
    $orderCounts = json_encode(array_column($customers, 'order_count'));

    // 每日銷售
    $stmt3 = $conn->query("
        SELECT o.order_date, SUM(od.quantity * p.price) AS total_sales
        FROM orders o
        JOIN order_details od ON o.order_id = od.order_id
        JOIN products p ON od.product_id = p.product_id
        GROUP BY o.order_date
        ORDER BY o.order_date ASC
    ");
    $sales = $stmt3->fetchAll(PDO::FETCH_ASSOC);
    $salesDates = json_encode(array_column($sales, 'order_date'));
    $salesTotals = json_encode(array_column($sales, 'total_sales'));

    // 供應商統計
    $stmt4 = $conn->query("
        SELECT s.supplier_name, COUNT(sp.product_id) AS product_count
        FROM suppliers s
        JOIN supplier_products sp ON s.supplier_id = sp.supplier_id
        GROUP BY s.supplier_name
    ");
    $suppliers = $stmt4->fetchAll(PDO::FETCH_ASSOC);
    $supplierNames = json_encode(array_column($suppliers, 'supplier_name'), JSON_UNESCAPED_UNICODE);
    $supplierCounts = json_encode(array_column($suppliers, 'product_count'));

    // 庫存不足
    $stmt5 = $conn->query("
        SELECT name, stock FROM products WHERE stock < 10 ORDER BY stock ASC
    ");
    $lowStockItems = $stmt5->fetchAll(PDO::FETCH_ASSOC);

    // 銷售金額
    $stmt6 = $conn->query("
        SELECT p.name, SUM(od.quantity * p.price) AS total_sales
        FROM orders o
        JOIN order_details od ON o.order_id = od.order_id
        JOIN products p ON od.product_id = p.product_id
        GROUP BY p.name
        ORDER BY total_sales DESC
    ");
    $salesNames = $stmt6->fetchAll(PDO::FETCH_ASSOC);
    $salesProductNames = json_encode(array_column($salesNames, 'name'), JSON_UNESCAPED_UNICODE);
    $salesAmounts = json_encode(array_column($salesNames, 'total_sales'));

    // 城市訂單
    $stmt7 = $conn->query("
        SELECT 
            CASE 
                WHEN c.address LIKE N'%台北%' OR c.address LIKE '%Taipei%' THEN N'台北'
                WHEN c.address LIKE N'%新北%' OR c.address LIKE '%New Taipei%' THEN N'新北'
                WHEN c.address LIKE N'%桃園%' OR c.address LIKE '%Taoyuan%' THEN N'桃園'
                WHEN c.address LIKE N'%台中%' OR c.address LIKE '%Taichung%' THEN N'台中'
                WHEN c.address LIKE N'%台南%' OR c.address LIKE '%Tainan%' THEN N'台南'
                WHEN c.address LIKE N'%高雄%' OR c.address LIKE '%Kaohsiung%' THEN N'高雄'
                WHEN c.address LIKE N'%基隆%' OR c.address LIKE '%Keelung%' THEN N'基隆'
                WHEN c.address LIKE N'%新竹%' OR c.address LIKE '%Hsinchu%' THEN N'新竹'
                WHEN c.address LIKE N'%嘉義%' OR c.address LIKE '%Chiayi%' THEN N'嘉義'
                WHEN c.address LIKE N'%宜蘭%' OR c.address LIKE '%Yilan%' THEN N'宜蘭'
                WHEN c.address LIKE N'%花蓮%' OR c.address LIKE '%Hualien%' THEN N'花蓮'
                WHEN c.address LIKE N'%台東%' OR c.address LIKE '%Taitung%' THEN N'台東'
                WHEN c.address LIKE N'%澎湖%' OR c.address LIKE '%Penghu%' THEN N'澎湖'
                WHEN c.address LIKE N'%金門%' OR c.address LIKE '%Kinmen%' THEN N'金門'
                WHEN c.address LIKE N'%連江%' OR c.address LIKE '%Lienchiang%' THEN N'連江'
                ELSE N'其他地區'
            END AS city,
            COUNT(o.order_id) AS order_count,
            SUM(od.quantity * od.price) AS total_sales
        FROM orders o
        JOIN customers c ON o.customer_id = c.customer_id
        JOIN order_details od ON o.order_id = od.order_id
        GROUP BY 
            CASE 
                WHEN c.address LIKE N'%台北%' OR c.address LIKE '%Taipei%' THEN N'台北'
                WHEN c.address LIKE N'%新北%' OR c.address LIKE '%New Taipei%' THEN N'新北'
                WHEN c.address LIKE N'%桃園%' OR c.address LIKE '%Taoyuan%' THEN N'桃園'
                WHEN c.address LIKE N'%台中%' OR c.address LIKE '%Taichung%' THEN N'台中'
                WHEN c.address LIKE N'%台南%' OR c.address LIKE '%Tainan%' THEN N'台南'
                WHEN c.address LIKE N'%高雄%' OR c.address LIKE '%Kaohsiung%' THEN N'高雄'
                WHEN c.address LIKE N'%基隆%' OR c.address LIKE '%Keelung%' THEN N'基隆'
                WHEN c.address LIKE N'%新竹%' OR c.address LIKE '%Hsinchu%' THEN N'新竹'
                WHEN c.address LIKE N'%嘉義%' OR c.address LIKE '%Chiayi%' THEN N'嘉義'
                WHEN c.address LIKE N'%宜蘭%' OR c.address LIKE '%Yilan%' THEN N'宜蘭'
                WHEN c.address LIKE N'%花蓮%' OR c.address LIKE '%Hualien%' THEN N'花蓮'
                WHEN c.address LIKE N'%台東%' OR c.address LIKE '%Taitung%' THEN N'台東'
                WHEN c.address LIKE N'%澎湖%' OR c.address LIKE '%Penghu%' THEN N'澎湖'
                WHEN c.address LIKE N'%金門%' OR c.address LIKE '%Kinmen%' THEN N'金門'
                WHEN c.address LIKE N'%連江%' OR c.address LIKE '%Lienchiang%' THEN N'連江'
                ELSE N'其他地區'
            END
        ORDER BY order_count DESC
    ");
    $cityOrders = $stmt7->fetchAll(PDO::FETCH_ASSOC);
    $cityNames = json_encode(array_column($cityOrders, 'city'), JSON_UNESCAPED_UNICODE);
    $cityCounts = json_encode(array_column($cityOrders, 'order_count'));
    $citySales = json_encode(array_column($cityOrders, 'total_sales'));

    // 每週銷售
    $stmt8 = $conn->query("
        SELECT DATENAME(WEEKDAY, o.order_date) AS weekday, SUM(od.quantity * p.price) AS total_sales
        FROM orders o
        JOIN order_details od ON o.order_id = od.order_id
        JOIN products p ON od.product_id = p.product_id
        GROUP BY DATENAME(WEEKDAY, o.order_date)
    ");
    $weekSales = $stmt8->fetchAll(PDO::FETCH_ASSOC);
    $weekdays = json_encode(array_column($weekSales, 'weekday'), JSON_UNESCAPED_UNICODE);
    $weekdayTotals = json_encode(array_column($weekSales, 'total_sales'));
    ?>

    <script>
    // 設置圖表全局配置
    Chart.defaults.font.family = "'Microsoft JhengHei', sans-serif";
    Chart.defaults.font.size = 14;
    Chart.defaults.plugins.legend.position = 'bottom';
    Chart.defaults.plugins.legend.labels.padding = 20;
    Chart.defaults.plugins.tooltip.padding = 10;
    Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    Chart.defaults.plugins.tooltip.cornerRadius = 4;

    // 熱門產品圖表
    new Chart(document.getElementById("topProductsChart"), {
        type: 'bar',
        data: {
            labels: <?= $productNames ?>,
            datasets: [{
                label: '總銷售數量',
                data: <?= $productQuantities ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        title: function(context) {
                            // 顯示完整產品名稱
                            return context[0].label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0, 0, 0, 0.1)' }
                },
                x: {
                    ticks: {
                        font: { size: 12 },
                        maxRotation: 30,
                        minRotation: 30,
                        callback: function(value, index, values) {
                            const label = this.getLabelForValue(value);
                            return label.length > 10 ? label.slice(0, 10) + '...' : label;
                        }
                    },
                    grid: { display: false }
                }
            }
        }
    });

    // 客戶訂購圖表
    new Chart(document.getElementById("topCustomersChart"), {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_column($customers, 'customer_id'), JSON_UNESCAPED_UNICODE) ?>,
            datasets: [{
                label: '訂單數量',
                data: <?= $orderCounts ?>,
                backgroundColor: 'rgba(255, 99, 132, 0.7)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        title: function(context) {
                            // 顯示完整客戶資訊
                            const idx = context[0].dataIndex;
                            const info = <?= $customerIds ?>;
                            return info[idx];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0, 0, 0, 0.1)' }
                },
                x: {
                    ticks: {
                        font: { size: 12 },
                        maxRotation: 30,
                        minRotation: 30,
                        callback: function(value, index, values) {
                            const label = this.getLabelForValue(value);
                            return label.length > 8 ? label.slice(0, 8) + '...' : label;
                        }
                    },
                    grid: { display: false }
                }
            }
        }
    });

    // 每日銷售圖表
    new Chart(document.getElementById("dailySalesChart"), {
        type: 'line',
        data: {
            labels: <?= $salesDates ?>,
            datasets: [{
                label: '總銷售金額',
                data: <?= $salesTotals ?>,
                fill: false,
                borderColor: 'rgba(75, 192, 192, 1)',
                tension: 0.1
            }]
        }
    });

    // 供應商圖表
    new Chart(document.getElementById("supplierStatsChart"), {
        type: 'bar',
        data: {
            labels: <?= $supplierNames ?>,
            datasets: [{
                label: '提供商品數量',
                data: <?= $supplierCounts ?>,
                backgroundColor: 'rgba(153, 102, 255, 0.7)'
            }]
        }
    });

    // 銷售金額圖表
    new Chart(document.getElementById("salesAmountChart"), {
        type: 'bar',
        data: {
            labels: <?= $salesProductNames ?>,
            datasets: [{
                label: '銷售金額',
                data: <?= $salesAmounts ?>,
                backgroundColor: 'rgba(255, 206, 86, 0.7)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        title: function(context) {
                            // 顯示完整產品名稱
                            return context[0].label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0, 0, 0, 0.1)' }
                },
                x: {
                    ticks: {
                        font: { size: 12 },
                        maxRotation: 30,
                        minRotation: 30,
                        callback: function(value, index, values) {
                            const label = this.getLabelForValue(value);
                            return label.length > 10 ? label.slice(0, 10) + '...' : label;
                        }
                    },
                    grid: { display: false }
                }
            }
        }
    });

    // 城市訂單圖表
    new Chart(document.getElementById("cityOrderChart"), {
        type: 'bar',
        data: {
            labels: <?= $cityNames ?>,
            datasets: [{
                label: '訂單數量',
                data: <?= $cityCounts ?>,
                backgroundColor: 'rgba(255, 159, 64, 0.7)',
                borderColor: 'rgba(255, 159, 64, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        title: function(context) {
                            return context[0].label;
                        },
                        afterLabel: function(context) {
                            const citySales = <?= $citySales ?>;
                            const index = context.dataIndex;
                            return '總銷售金額: $' + citySales[index].toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0, 0, 0, 0.1)' },
                    title: {
                        display: true,
                        text: '訂單數量'
                    }
                },
                x: {
                    ticks: {
                        font: { size: 12 },
                        maxRotation: 45,
                        minRotation: 45
                    },
                    grid: { display: false },
                    title: {
                        display: true,
                        text: '城市'
                    }
                }
            }
        }
    });

    // 每週銷售圖表
    new Chart(document.getElementById("weekdaySalesChart"), {
        type: 'line',
        data: {
            labels: <?= $weekdays ?>,
            datasets: [{
                label: '總銷售金額',
                data: <?= $weekdayTotals ?>,
                fill: false,
                borderColor: 'rgba(153, 255, 153, 1)',
                tension: 0.1
            }]
        }
    });

    // 庫存不足表格
    document.getElementById("lowStockTable").innerHTML = `
        <table class="table table-bordered table-sm table-striped">
            <thead><tr><th>產品名稱</th><th>庫存量</th></tr></thead>
            <tbody>
                <?= implode('', array_map(fn($row) => "<tr><td>{$row['name']}</td><td>{$row['stock']}</td></tr>", $lowStockItems)) ?>
            </tbody>
        </table>
    `;
    </script>

    <div class="mb-5"></div>
    <script>
    function scrollToChart(id) {
        const element = document.getElementById(id);
        if (element) {
            const headerOffset = 80;
            const elementPosition = element.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    }
    </script>
</body>
</html>
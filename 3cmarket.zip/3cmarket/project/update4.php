<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>客戶資料維護</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
  <div id="header">
    <h1>客戶資料維護</h1>
  </div>
    
<div id="contents">
<h2 style="text-align: center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>
<?php
        // For macOS: Connect to SQL Server via ODBC Driver 17 and trust server certificate
        include 'connect.php';
		if(empty($_POST['supplier_name']))	
		{
			echo "<div class='center-black'>!!!! 請輸入供應商名稱 !!!</div>";
		}
		else
		{        
	    $supplier_name=$_POST['supplier_name'];
		$sql = "SELECT * FROM dbo.suppliers WHERE supplier_name = :supplier_name";
		$stmt = $conn->prepare($sql);
		$stmt->execute([$supplier_name]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
		if(empty($row['supplier_name']))	
		{
			echo"<div class='center-black'>!!! 無此供應商資料 !!!</div>";
		}
		else
		{	
?>
        <form name="form" action="http://localhost:8080/project/update_data_4.php" method="post" accept-charset="UTF-8">
		<div class="detail_box clearfix">
        <div class="form-card">
            <h3 style="text-align: center; color: black;">修改供應商資料</h3>
            <label for="supplier_id">供應商編號:</label>
            <input type="text" id="supplier_id" name="supplier_id" value="<?php echo $row['supplier_id']; ?>" readonly style="font-size: 14px;" />

            <label for="supplier_name">供應商名稱：</label>
            <input type="text" id="supplier_name" name="supplier_name" value="<?php echo htmlspecialchars($row['supplier_name']); ?>" style="font-size: 14px;" />

            <label for="contact_name">聯絡人姓名：</label>
            <input type="text" id="contact_name" name="contact_name" value="<?php echo htmlspecialchars($row['contact_name']); ?>" style="font-size: 14px;" />

            <label for="phone">電話：</label>
            <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($row['phone']); ?>" style="font-size: 14px;" />

            <label for="email">電子郵件：</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" style="font-size: 14px;" />

            <label for="address">地址：</label>
            <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($row['address']); ?>" style="font-size: 14px;" />

            <label for="start_date">合作開始日期：</label>
            <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($row['start_date']); ?>" style="font-size: 14px;" />

            <label for="notes">備註：</label>
            <textarea id="notes" name="notes" style="font-size: 14px; width: 100%; height: 60px;"><?php echo htmlspecialchars($row['notes']); ?></textarea>

            <input type="reset" value="清除表單" style="font-size: 14px;" />
            <input id="submit" name="submit" type="submit" value="送出" style="font-size: 14px;" />
        </div>
        </div>
        </form>	
		<?php	} }?>
</div>

</body>
</html>
<?php
// 資料庫連線設定
include 'connect.php';

// 接收與處理表單資料
function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$name           = sanitize($_POST['name']);
$price          = sanitize($_POST['price']);
$description    = sanitize($_POST['description']);
$status = 'Active';
$stock          = sanitize($_POST['stock']);

// 驗證欄位
if (empty($name) || empty($price) || empty($stock)) {
    echo "<script>alert('請填寫必填欄位（名稱、價格與庫存）！'); history.back();</script>";
    exit();
}

// 寫入資料
$sql = "INSERT INTO products (name, price, description, stock, status)
        VALUES (:name, :price, :description, :stock, :status)";

$stmt = $conn->prepare($sql);
$stmt->execute([
    ':name' => $name,
    ':price' => $price,
    ':description' => $description,
    ':stock' => $stock,
    ':status' => $status
]);

echo "<script>alert('產品新增成功！'); window.location.href='insert3.html';</script>";
?>

<?php
header("Content-Type:text/html; charset=utf-8");
?>

<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>客戶修改結果</title>
  <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="wrapper-02">
<div id="header">
  <h1>客戶修改結果</h1>
</div>

<div id="contents">
  <h2 style="text-align:center;"> <a href="http://localhost:8080/project/index.php">首頁</a> </h2>

<?php
  include "connect.php";

  $customer_id = $_POST['customer_id'];
  $customer_name = $_POST['customername'];
  $gender = $_POST['gender'];
  $age = $_POST['age'];
  $phone = $_POST['phone'];
  $address = $_POST['address'];
  $email = $_POST['email'];

  // 1. 開始交易
  //sqlsrv_begin_transaction($conn);

  try {
    $conn->beginTransaction();

    $sql = "UPDATE dbo.customers SET 
                customer_name = :customer_name,
                gender = :gender,
                age = :age,
                phone = :phone,
                address = :address,
                email = :email
            WHERE customer_id = :customer_id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':customer_name', $customer_name);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':age', $age);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':customer_id', $customer_id);

    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $conn->commit();
        echo "<div class='center-black'><p>客戶編號: ".$customer_id." 資料已修改完成。</p><p>請點首頁回到系統管理畫面!</p></div>";
    } else {
        $conn->rollBack();
        echo "<div class='center-black'>資料未更新（可能資料相同），交易已回滾。</div>";
    }
} catch (PDOException $e) {
    $conn->rollBack();
    echo "<div class='center-black'><p>修改失敗：交易已回滾</p><pre>".$e->getMessage()."</pre></div>";
}

  // 4. 結束連線（可選）
  $conn = null;
?>
</div>
</body>
</html>
<?php
include 'connect.php';

$supplier_name = $_POST['supplier_name'] ?? '';

$sql = "SELECT * FROM suppliers WHERE 1=1";
$params = [];

if (!empty($supplier_name)) {
    $sql .= " AND supplier_name LIKE :supplier_name";
    $params[':supplier_name'] = "%$supplier_name%";
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>供應商查詢結果</title>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>供應商查詢結果</h2>
    <?php if (count($results) > 0): ?>
        <table border="1">
            <tr>
                <th>供應商編號</th>
                <th>供應商名稱</th>
                <th>聯絡人名字</th>
                <th>電話</th>
                <th>信箱</th>
                <th>地址</th>
                <th>合作開始時間</th>
                <th>備註</th>
            </tr>
            <?php foreach ($results as $row): ?>
                <tr>
                    <td><?php echo $row['supplier_id']; ?></td>
                    <td><?php echo $row['supplier_name']; ?></td>
                    <td><?php echo $row['contact_name']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['address']; ?></td>
                    <td><?php echo $row['start_date']; ?></td>
                    <td><?php echo $row['notes']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>查無供應商資料。</p>
    <?php endif; ?>
</body>
</html>